# Broly Culo

Adds Broly Culo as a brand new enemy with its own ai and sounds.