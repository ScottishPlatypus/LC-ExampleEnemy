## 1.0.0

- Initial release

## 1.0.1

- Increased spawn chance
- Fixed compatibility issues with other mods

## 1.1.0

- Fixed a bug preventing broly from spawning correctly
- Added death animation and sound