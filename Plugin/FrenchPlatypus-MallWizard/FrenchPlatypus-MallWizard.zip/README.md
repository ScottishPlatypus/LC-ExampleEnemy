# Mall Wizard

Adds the Mall Wizard as a brand new enemy with its own ai and sounds.

Beware of his powerful magic!