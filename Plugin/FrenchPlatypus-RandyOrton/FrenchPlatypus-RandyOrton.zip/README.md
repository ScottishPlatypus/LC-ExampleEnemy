# Randy Orton

Adds Randy Orton as a brand new enemy with its own ai, sounds and animations.