# Randy Orton

The Three most dangerous letters in sport entertainment.