## 1.0.0

- Initial Release

## 1.1.0

- Fixed some server issues
- Added pin count to behaviour
- Fixed some issues with terminal entry

## 1.1.1

- Increased spawn chance
- Fixed compatibility issues with other mods

## 1.2.0

- Fixed a bug preventing Randy from spawning correctly
- Changed death music to be shorter

## 1.3.0

- Fixed Networking issues preventif Randy from killing players