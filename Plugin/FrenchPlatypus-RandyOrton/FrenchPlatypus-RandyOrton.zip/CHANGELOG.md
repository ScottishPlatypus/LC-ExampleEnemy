## 0.0.3

- Fixed some server issues.

- Added pin count to behaviour.

- Fixed some issues with terminal entry.